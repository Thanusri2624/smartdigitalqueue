-- Priority queue for vulnerable groups
-- Run: mysql -u root -p smart_queue < migration_priority.sql
-- If you get "Duplicate column" error, the columns already exist - that's OK.

USE smart_queue;

-- Add priority_type to tokens (senior, pregnant, disabled, emergency)
ALTER TABLE tokens ADD COLUMN priority_type VARCHAR(30) NULL DEFAULT NULL AFTER priority;

-- Add priority to slot_bookings
ALTER TABLE slot_bookings ADD COLUMN priority_type VARCHAR(30) NULL DEFAULT NULL AFTER token_id;

-- Notifications table for user alerts
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_mobile VARCHAR(20) NOT NULL,
    token_id INT NULL,
    message VARCHAR(255) NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE SET NULL
);
