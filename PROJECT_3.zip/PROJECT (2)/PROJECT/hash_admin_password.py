"""
One-time script to hash admin password for Smart Queue.
Run: python hash_admin_password.py
Use the output to UPDATE admin table: UPDATE admin SET password='<hash>' WHERE username='admin';
"""
from werkzeug.security import generate_password_hash

password = input("Enter admin password to hash: ")
hashed = generate_password_hash(password)
print(f"\nHashed password (use in SQL):\n{hashed}")
print("\nSQL: UPDATE admin SET password=%s WHERE username='your_admin';" % repr(hashed))
