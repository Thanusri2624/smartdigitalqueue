-- Smart Queue Management System - Full Schema
-- Run: mysql -u root -p smart_queue < database.sql
-- Or create DB first: CREATE DATABASE IF NOT EXISTS smart_queue; USE smart_queue;

SET NAMES utf8mb4;

-- ----------------------------
-- Users (citizens)
-- ----------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mobile VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Admin
-- ----------------------------
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Services (multi-service: Banking, Certificates, Hospital, etc.)
-- ----------------------------
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    description VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------
-- Required documents per service
-- ----------------------------
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_id INT NOT NULL,
    document_name VARCHAR(100) NOT NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- ----------------------------
-- Average service time per service (for AI prediction)
-- ----------------------------
CREATE TABLE IF NOT EXISTS service_time (
    service_id INT PRIMARY KEY,
    avg_time INT NOT NULL DEFAULT 5 COMMENT 'Average minutes per token',
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- ----------------------------
-- Slots (capacity per service/date/time)
-- ----------------------------
CREATE TABLE IF NOT EXISTS slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_id INT NOT NULL,
    slot_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    capacity INT NOT NULL DEFAULT 5,
    booked_count INT NOT NULL DEFAULT 0,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    UNIQUE KEY uk_slot (service_id, slot_date, slot_time)
);

-- ----------------------------
-- Tokens (queue entries)
-- ----------------------------
CREATE TABLE IF NOT EXISTS tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_id INT NOT NULL,
    status ENUM('WAITING', 'SERVING', 'COMPLETED', 'MISSED') DEFAULT 'WAITING',
    priority INT NOT NULL DEFAULT 0 COMMENT 'Higher = served first; admin can change',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    served_at TIMESTAMP NULL COMMENT 'When status became SERVING',
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- ----------------------------
-- Slot bookings (user reservations)
-- ----------------------------
CREATE TABLE IF NOT EXISTS slot_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_mobile VARCHAR(20) NOT NULL,
    service_id INT NOT NULL,
    slot_id INT NULL,
    slot_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    status ENUM('BOOKED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED', 'MISSED') DEFAULT 'BOOKED',
    token_id INT NULL,
    qr_path VARCHAR(255) NULL COMMENT 'Path to generated QR image',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES slots(id) ON DELETE SET NULL,
    FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE SET NULL
);

-- ----------------------------
-- Optional: token_events for analytics (when status changed)
-- ----------------------------
CREATE TABLE IF NOT EXISTS token_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token_id INT NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE CASCADE
);

-- ----------------------------
-- Migrations: add columns if tables already exist (run separately if needed)
-- ----------------------------
-- ALTER TABLE tokens ADD COLUMN IF NOT EXISTS priority INT NOT NULL DEFAULT 0;
-- ALTER TABLE tokens ADD COLUMN IF NOT EXISTS served_at TIMESTAMP NULL;
-- ALTER TABLE tokens ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP NULL;
-- ALTER TABLE tokens MODIFY status ENUM('WAITING', 'SERVING', 'COMPLETED', 'MISSED') DEFAULT 'WAITING';
-- ALTER TABLE slot_bookings ADD COLUMN IF NOT EXISTS qr_path VARCHAR(255) NULL;
-- ALTER TABLE slot_bookings ADD COLUMN IF NOT EXISTS slot_id INT NULL;
-- ALTER TABLE slot_bookings MODIFY status ENUM('BOOKED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED', 'MISSED') DEFAULT 'BOOKED';

-- Seed default admin (username: admin, password: admin123 - CHANGE IN PRODUCTION)
INSERT IGNORE INTO admin (username, password) VALUES ('admin', 'admin123');

-- Seed sample services
INSERT IGNORE INTO services (id, service_name, description) VALUES
(1, 'Banking', 'Account and loan services'),
(2, 'Certificates', 'Birth, income, and other certificates'),
(3, 'Hospital OPD', 'Outpatient department');

INSERT IGNORE INTO service_time (service_id, avg_time) VALUES (1, 5), (2, 7), (3, 10);
INSERT IGNORE INTO documents (service_id, document_name) VALUES
(1, 'ID Proof'), (1, 'Address Proof'),
(2, 'ID Proof'), (2, 'Application Form'),
(3, 'ID Proof'), (3, 'Previous Prescription');
