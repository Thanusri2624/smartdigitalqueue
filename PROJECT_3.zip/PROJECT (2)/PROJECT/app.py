"""
Smart Queue Management System - Production-ready with AI, analytics, and reliability.
"""
from flask import Flask, render_template, request, redirect, session, flash, jsonify, send_file
from flask_wtf.csrf import CSRFProtect
import mysql.connector
from werkzeug.security import check_password_hash, generate_password_hash
import os
from dotenv import load_dotenv
from datetime import datetime, date, time, timedelta
from contextlib import contextmanager
import csv
import io
import qrcode

# ---------------- LOAD ENV ----------------
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")
csrf = CSRFProtect(app)

# ---------------- DATABASE: per-request connection ----------------
def get_db():
    """Create a new DB connection. Caller must close cursor; we close conn in teardown."""
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME", "smart_queue"),
        autocommit=False,
    )

@app.teardown_appcontext
def close_db(exception=None):
    """Close DB connection at end of request (if stored in g)."""
    from flask import g
    if hasattr(g, "db_conn") and g.db_conn:
        try:
            g.db_conn.close()
        except Exception:
            pass

def db_connection():
    """Get DB connection for this request (creates and stores in g)."""
    from flask import g
    if not hasattr(g, "db_conn"):
        g.db_conn = get_db()
    return g.db_conn

# ---------------- HELPERS ----------------
def get_token_display_number(cursor, service_id, token_id):
    """Per-service token number (starts from 1)."""
    if not token_id:
        return None
    cursor.execute(
        "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id <= %s",
        (service_id, token_id)
    )
    return cursor.fetchone()[0]

def parse_time(s):
    """Parse '09:00' or '09:00:00' to time object for MySQL TIME."""
    if s is None:
        return None
    if hasattr(s, "hour"):
        return s
    s = str(s).strip()
    if not s:
        return None
    parts = s.split(":")
    h = int(parts[0]) if len(parts) > 0 else 0
    m = int(parts[1]) if len(parts) > 1 else 0
    sec = int(parts[2]) if len(parts) > 2 else 0
    return time(h, m, sec)

def predict_wait_time(avg_time, people_ahead, current_hour, day_of_week):
    """AI-based real-time wait time prediction (minutes).
    Factors: base avg_time, rush hours (10-13, 15-17), weekends, queue length."""
    adjusted = float(avg_time or 5)
    if 10 <= current_hour <= 13:
        adjusted += 3
    if 15 <= current_hour <= 17:
        adjusted += 2
    if day_of_week >= 5:
        adjusted *= 1.1
    if people_ahead >= 10:
        adjusted *= 1.4
    elif people_ahead >= 5:
        adjusted *= 1.2
    elif people_ahead <= 2:
        adjusted *= 0.8
    return max(1, int(people_ahead * adjusted))

def slot_crowd_label(booked, capacity):
    """Return Low / Medium / High for slot recommendation."""
    cap = max(1, capacity)
    ratio = booked / cap
    if ratio < 0.4:
        return "Low Crowd"
    if ratio < 0.75:
        return "Medium"
    return "High"

def generate_qr_for_booking(booking_id, service_name, slot_date, slot_time_str):
    """Generate QR image for booking and return relative path."""
    qr_dir = os.path.join(app.static_folder, "qr")
    os.makedirs(qr_dir, exist_ok=True)
    data = f"SQ|B|{booking_id}|{service_name}|{slot_date}|{slot_time_str}"
    img = qrcode.make(data)
    filename = f"booking_{booking_id}.png"
    path = os.path.join(qr_dir, filename)
    img.save(path)
    return f"/static/qr/{filename}"

def generate_qr_for_token(token_id, service_id, token_display, service_name=""):
    """Generate QR image for queue token - scannable at service counter."""
    qr_dir = os.path.join(app.static_folder, "qr")
    os.makedirs(qr_dir, exist_ok=True)
    data = f"SQ|T|{token_id}|{service_id}|{token_display}"
    try:
        from flask import request
        base = request.url_root.rstrip("/") if request else ""
        scan_url = f"{base}/scan/{token_id}"
        img = qrcode.make(scan_url)
    except Exception:
        img = qrcode.make(data)
    filename = f"token_{token_id}.png"
    path = os.path.join(qr_dir, filename)
    img.save(path)
    return f"/static/qr/{filename}"

# Priority queue: higher value = served first (emergency > senior > pregnant > disabled > normal)
PRIORITY_TYPE_RANK = {"emergency": 100, "senior": 50, "pregnant": 40, "disabled": 30}

# ---------------- CITIZEN LOGIN ----------------
def _validate_mobile(mobile):
    """Validate mobile number: digits only, 10-15 chars."""
    clean = "".join(c for c in str(mobile).strip() if c.isdigit())
    return clean if 10 <= len(clean) <= 15 else None

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        mobile_raw = request.form.get("mobile", "").strip()
        password = request.form.get("password", "")

        if not password:
            flash("Please enter your password.", "error")
            return render_template("login.html", mobile=mobile_raw)

        mobile = _validate_mobile(mobile_raw) or mobile_raw
        if not mobile:
            flash("Please enter a valid mobile number (10-15 digits).", "error")
            return render_template("login.html", mobile=mobile_raw)

        conn = db_connection()
        cursor = conn.cursor()
        try:
            # Support both normalized and raw mobile (for backward compatibility)
            cursor.execute("SELECT id, mobile, password FROM users WHERE mobile=%s OR mobile=%s LIMIT 1", (mobile, mobile_raw))
            user = cursor.fetchone()
            if not user:
                flash("No account found with this mobile number. Please register first.", "error")
                cursor.close()
                return render_template("login.html", mobile=mobile_raw)

            stored_hash = user[2]
            if not stored_hash:
                flash("Account error. Please contact support.", "error")
                cursor.close()
                return render_template("login.html", mobile=mobile_raw)

            try:
                if check_password_hash(stored_hash, password):
                    session["user"] = user[1]
                    session["user_id"] = user[0]
                    cursor.close()
                    flash("Welcome back!", "success")
                    return redirect("/dashboard")
            except (ValueError, TypeError) as e:
                # Legacy plain-text fallback (for migrated data)
                if stored_hash == password:
                    hashed = generate_password_hash(password, method="pbkdf2:sha256")
                    cursor.execute("UPDATE users SET password=%s WHERE id=%s", (hashed, user[0]))
                    conn.commit()
                    session["user"] = user[1]
                    session["user_id"] = user[0]
                    cursor.close()
                    flash("Welcome back! Your account has been updated.", "success")
                    return redirect("/dashboard")
                flash("Invalid password. Please try again.", "error")
            else:
                flash("Invalid password. Please try again.", "error")
        finally:
            try:
                cursor.close()
            except Exception:
                pass

    return render_template("login.html")

# ---------------- USER REGISTRATION (optional - for new users) ----------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        mobile_raw = request.form.get("mobile", "").strip()
        password = request.form.get("password", "")

        if not password:
            flash("Please enter a password.", "error")
            return render_template("register.html", mobile=mobile_raw)

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            return render_template("register.html", mobile=mobile_raw)

        mobile = _validate_mobile(mobile_raw)
        if not mobile:
            flash("Please enter a valid mobile number (10-15 digits).", "error")
            return render_template("register.html", mobile=mobile_raw)

        conn = db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id FROM users WHERE mobile=%s", (mobile,))
            if cursor.fetchone():
                flash("This mobile number is already registered. Please login.", "error")
                return render_template("register.html", mobile=mobile_raw)

            # Use pbkdf2:sha256 for cross-platform reliability (scrypt can fail on some systems)
            hashed = generate_password_hash(password, method="pbkdf2:sha256")
            cursor.execute("INSERT INTO users (mobile, password) VALUES (%s, %s)", (mobile, hashed))
            conn.commit()

            # Auto-login after successful registration for better UX
            cursor.execute("SELECT id FROM users WHERE mobile=%s", (mobile,))
            new_user = cursor.fetchone()
            if new_user:
                session["user"] = mobile
                session["user_id"] = new_user[0]
                cursor.close()
                flash("Account created successfully! Welcome to Smart Queue.", "success")
                return redirect("/dashboard")
        except Exception as e:
            conn.rollback()
            flash("Registration failed. Please try again.", "error")
            return render_template("register.html", mobile=mobile_raw)
        finally:
            try:
                cursor.close()
            except Exception:
                pass

        flash("Registration successful. Please login.", "success")
        return redirect("/")
    return render_template("register.html")

# ---------------- USER DASHBOARD ----------------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/")

    user_mobile = session["user"]
    conn = db_connection()
    cursor = conn.cursor()

    upcoming = []
    try:
        cursor.execute("""
            SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id, sb.qr_path
            FROM slot_bookings sb
            JOIN services s ON sb.service_id = s.id
            WHERE sb.user_mobile = %s AND sb.status IN ('BOOKED', 'CHECKED_IN')
            ORDER BY sb.slot_date ASC, sb.slot_time ASC
            LIMIT 5
        """, (user_mobile,))
        upcoming = cursor.fetchall()
    except Exception:
        try:
            cursor.execute("""
                SELECT sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id
                FROM slot_bookings sb
                JOIN services s ON sb.service_id = s.id
                WHERE sb.user_mobile = %s AND sb.status IN ('BOOKED', 'CHECKED_IN')
                ORDER BY sb.slot_date ASC, sb.slot_time ASC
                LIMIT 5
            """, (user_mobile,))
            upcoming = cursor.fetchall()
        except Exception:
            try:
                cursor.execute("""
                    SELECT sb.service_id, s.service_name, sb.status, sb.token_id
                    FROM slot_bookings sb
                    JOIN services s ON sb.service_id = s.id
                    WHERE sb.user_mobile = %s AND sb.status IN ('BOOKED', 'CHECKED_IN')
                    LIMIT 5
                """, (user_mobile,))
                upcoming = cursor.fetchall()
            except Exception:
                upcoming = []

    # Next booking with wait prediction (row: 8 cols = id,svc_id,name,date,time,status,token_id,qr | 6 = svc_id,name,date,time,status,token_id | 4 = svc_id,name,status,token_id)
    next_booking = None
    if upcoming:
        row = upcoming[0]
        n = len(row)
        b_id = row[0] if n >= 8 else None
        svc_id = row[1] if n >= 8 else row[0]
        svc_name = row[2] if n >= 3 else (row[1] if n >= 2 else "")
        slot_date = row[3] if n >= 5 else date.today()
        slot_time = row[4] if n >= 5 else None
        status = row[5] if n >= 6 else (row[2] if n >= 4 else "")
        token_id = row[6] if n >= 7 else (row[5] if n >= 6 else (row[3] if n >= 4 else None))
        qr_path = row[7] if n >= 8 else None
        slot_time_str = slot_time.strftime("%H:%M") if slot_time and hasattr(slot_time, "strftime") else (str(slot_time)[:5] if slot_time else "—")
        people_ahead = 0
        est_wait = 0
        if token_id and status == "CHECKED_IN":
            try:
                cursor.execute("""
                    SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id < %s AND status NOT IN ('COMPLETED', 'MISSED')
                """, (svc_id, token_id))
                people_ahead = cursor.fetchone()[0]
                cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (svc_id,))
                ar = cursor.fetchone()
                avg_time = (ar[0] if ar and ar[0] is not None else 5)
                est_wait = predict_wait_time(avg_time, people_ahead, datetime.now().hour, datetime.now().weekday())
            except Exception:
                pass
        next_booking = {
            "id": b_id, "service_id": svc_id, "service_name": svc_name, "slot_date": slot_date, "slot_time": slot_time_str,
            "status": status, "token_id": token_id, "people_ahead": people_ahead, "est_wait_min": est_wait, "qr_path": qr_path
        }

    try:
        cursor.execute("SELECT COUNT(*) FROM slot_bookings WHERE user_mobile=%s", (user_mobile,))
        total_bookings = cursor.fetchone()[0]
    except Exception:
        total_bookings = 0
    cursor.close()

    return render_template("dashboard.html", upcoming=upcoming, next_booking=next_booking, total_bookings=total_bookings)

# ---------------- SERVICES ----------------
@app.route("/services")
def services():
    if "user" not in session:
        return redirect("/")

    conn = db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, service_name, description FROM services ORDER BY service_name")
    except Exception:
        cursor.execute("SELECT id, service_name FROM services ORDER BY service_name")
    rows = cursor.fetchall()
    # Normalize to (id, service_name, description|None) for templates
    services_list = [(r[0], r[1], r[2] if len(r) > 2 else None) for r in rows]
    cursor.close()
    return render_template("services.html", services=services_list)

# ---------------- SLOT BOOKING (fix: proper INSERT and slot_id, QR) ----------------
@app.route("/slot_booking/<int:service_id>", methods=["GET", "POST"])
def slot_booking(service_id):
    if "user" not in session:
        return redirect("/")

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, service_name FROM services WHERE id=%s", (service_id,))
    svc = cursor.fetchone()
    if not svc:
        cursor.close()
        flash("Service not found.", "error")
        return redirect("/services")

    service_name = svc[1]
    user_mobile = session["user"]
    today = date.today()
    time_slots = ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"]

    if request.method == "POST":
        slot_date_str = request.form.get("slot_date", "").strip()
        slot_time_str = request.form.get("slot_time", "").strip()
        if not slot_date_str or not slot_time_str:
            flash("Please select date and time.", "error")
            cursor.close()
            return redirect(f"/slot_booking/{service_id}")

        try:
            slot_date = datetime.strptime(slot_date_str, "%Y-%m-%d").date()
        except ValueError:
            flash("Invalid date.", "error")
            cursor.close()
            return redirect(f"/slot_booking/{service_id}")

        slot_time_val = parse_time(slot_time_str)
        if not slot_time_val:
            flash("Invalid time.", "error")
            cursor.close()
            return redirect(f"/slot_booking/{service_id}")

        cursor.execute(
            "SELECT id, capacity, booked_count FROM slots WHERE service_id=%s AND slot_date=%s AND slot_time=%s",
            (service_id, slot_date, slot_time_val)
        )
        slot = cursor.fetchone()
        if not slot:
            cursor.execute(
                "INSERT INTO slots (service_id, slot_date, slot_time, capacity, booked_count) VALUES (%s, %s, %s, 5, 0)",
                (service_id, slot_date, slot_time_val)
            )
            conn.commit()
            slot_id = cursor.lastrowid
            capacity, booked_count = 5, 0
        else:
            slot_id, capacity, booked_count = slot[0], slot[1], slot[2]

        if booked_count >= capacity:
            flash("This slot is full. Please choose another.", "error")
            cursor.close()
            return redirect(f"/slot_booking/{service_id}")

        priority_type = request.form.get("priority_type") or None
        if priority_type and priority_type not in ("senior", "pregnant", "disabled", "emergency"):
            priority_type = None

        try:
            cursor.execute(
                """INSERT INTO slot_bookings (user_mobile, service_id, slot_id, slot_date, slot_time, status, priority_type)
                   VALUES (%s, %s, %s, %s, %s, 'BOOKED', %s)""",
                (user_mobile, service_id, slot_id, slot_date, slot_time_val, priority_type)
            )
        except mysql.connector.errors.ProgrammingError:
            try:
                cursor.execute(
                    """INSERT INTO slot_bookings (user_mobile, service_id, slot_id, slot_date, slot_time, status)
                       VALUES (%s, %s, %s, %s, %s, 'BOOKED')""",
                    (user_mobile, service_id, slot_id, slot_date, slot_time_val)
                )
            except Exception:
                cursor.execute(
                    """INSERT INTO slot_bookings (user_mobile, service_id, slot_date, slot_time, status)
                       VALUES (%s, %s, %s, %s, 'BOOKED')""",
                    (user_mobile, service_id, slot_date, slot_time_val)
                )
        conn.commit()
        booking_id = cursor.lastrowid

        cursor.execute("UPDATE slots SET booked_count = booked_count + 1 WHERE id=%s", (slot_id,))
        conn.commit()

        qr_path = None
        try:
            qr_path = generate_qr_for_booking(booking_id, service_name, slot_date_str, slot_time_str[:5])
            cursor.execute("UPDATE slot_bookings SET qr_path=%s WHERE id=%s", (qr_path, booking_id))
            conn.commit()
        except (mysql.connector.errors.ProgrammingError, Exception):
            pass  # qr_path column may not exist or QR generation failed

        # AI: estimated wait on arrival (rough)
        cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (service_id,))
        ar = cursor.fetchone()
        avg_time = (ar[0] if ar and ar[0] is not None else 5)
        est_wait = predict_wait_time(avg_time, booked_count + 1, slot_time_val.hour, slot_date.weekday())

        cursor.close()
        flash(f"Slot booked for {slot_date_str} at {slot_time_str}. Estimated wait on arrival: ~{est_wait} min. QR saved.", "success")
        return redirect("/booking_confirmation/" + str(booking_id))

    slots_by_date = {}
    for i in range(7):
        d = today + timedelta(days=i)
        cursor.execute(
            "SELECT slot_time, capacity, booked_count FROM slots WHERE service_id=%s AND slot_date=%s",
            (service_id, d)
        )
        rows = cursor.fetchall()
        available = {}
        for t in time_slots:
            available[t] = {"available": 5, "label": "Low Crowd"}
        for row in rows:
            t_obj = row[0]
            t_key = t_obj.strftime("%H:%M") if hasattr(t_obj, "strftime") else str(t_obj)[:5]
            cap = row[1] or 5
            booked = row[2] or 0
            available[t_key] = {
                "available": max(0, cap - booked),
                "label": slot_crowd_label(booked, cap)
            }
        slots_by_date[d.isoformat()] = available

    cursor.close()
    return render_template(
        "slot_booking.html",
        service_id=service_id,
        service_name=service_name,
        slots_by_date=slots_by_date,
        time_slots=time_slots
    )

# ---------------- BOOKING CONFIRMATION (with wait prediction) ----------------
@app.route("/booking_confirmation/<int:booking_id>")
def booking_confirmation(booking_id):
    if "user" not in session:
        return redirect("/")
    user_mobile = session["user"]
    conn = db_connection()
    cursor = conn.cursor()
    row = None
    try:
        cursor.execute("""
            SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.qr_path, sb.created_at
            FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
            WHERE sb.id=%s AND sb.user_mobile=%s
        """, (booking_id, user_mobile))
        row = cursor.fetchone()
    except Exception:
        try:
            cursor.execute("""
                SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.created_at
                FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                WHERE sb.id=%s AND sb.user_mobile=%s
            """, (booking_id, user_mobile))
            row = cursor.fetchone()
        except Exception:
            pass
    if not row:
        cursor.close()
        flash("Booking not found or table has no id column.", "error")
        return redirect("/my_bookings")
    n = len(row)
    slot_time_str = row[4].strftime("%H:%M") if n > 4 and hasattr(row[4], "strftime") else (str(row[4])[:5] if n > 4 and row[4] else "—")
    qr_path = row[6] if n >= 8 else None
    try:
        cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (row[1],))
        ar = cursor.fetchone()
        avg_time = (ar[0] if ar and ar[0] is not None else 5)
    except Exception:
        avg_time = 5
    slot_date = row[3] if n > 3 else date.today()
    est = predict_wait_time(avg_time, 3, int(slot_time_str[:2]) if slot_time_str and slot_time_str[:2].isdigit() else 12, slot_date.weekday() if hasattr(slot_date, "weekday") else 0)
    cursor.close()
    return render_template("booking_confirmation.html",
        booking={"id": row[0], "service_name": row[2], "slot_date": slot_date, "slot_time": slot_time_str, "qr_path": qr_path},
        est_wait_min=est)

# ---------------- MY BOOKINGS ----------------
@app.route("/my_bookings")
def my_bookings():
    if "user" not in session:
        return redirect("/")

    user_mobile = session["user"]
    conn = db_connection()
    cursor = conn.cursor()
    rows = []
    try:
        cursor.execute("""
            SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id, sb.created_at, sb.qr_path
            FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
            WHERE sb.user_mobile = %s
            ORDER BY sb.slot_date DESC, sb.slot_time DESC
        """, (user_mobile,))
        rows = cursor.fetchall()
    except Exception:
        try:
            cursor.execute("""
                SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id, sb.created_at
                FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                WHERE sb.user_mobile = %s
                ORDER BY sb.slot_date DESC, sb.slot_time DESC
            """, (user_mobile,))
            rows = cursor.fetchall()
        except Exception:
            try:
                cursor.execute("""
                    SELECT sb.service_id, s.service_name, sb.status, sb.token_id
                    FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                    WHERE sb.user_mobile = %s
                """, (user_mobile,))
                rows = cursor.fetchall()
            except Exception:
                rows = []
    today = date.today()
    bookings = []
    for row in rows:
        n = len(row)
        b_id = row[0] if n >= 8 else None
        svc_id = row[1] if n >= 2 else row[0]
        svc_name = row[2] if n >= 3 else ""
        slot_date = row[3] if n >= 5 else today
        slot_time = row[4] if n >= 5 else None
        status = row[5] if n >= 6 else (row[2] if n >= 4 else "")
        token_id = row[6] if n >= 7 else (row[3] if n >= 4 else None)
        created_at = row[7] if n >= 8 else None
        qr_path = row[8] if n >= 9 else None
        slot_time_str = slot_time.strftime("%H:%M") if slot_time and hasattr(slot_time, "strftime") else (str(slot_time)[:5] if slot_time else "—")
        token_display = get_token_display_number(cursor, svc_id, token_id) if token_id else None
        can_check_in = status == "BOOKED" and slot_date <= today and b_id is not None
        now_time = datetime.now().time()
        can_cancel = b_id is not None and status == "BOOKED" and (
            slot_date > today or
            (slot_date == today and (not slot_time or not hasattr(slot_time, "hour") or slot_time > now_time))
        )
        bookings.append({
            "id": b_id, "service_id": svc_id, "service_name": svc_name,
            "slot_date": slot_date, "slot_time": slot_time_str,
            "status": status, "token_id": token_id, "token_display": token_display,
            "can_check_in": can_check_in, "can_cancel": can_cancel, "qr_path": qr_path
        })
    cursor.close()
    return render_template("my_bookings.html", bookings=bookings)

# ---------------- VIEW PREVIOUS HISTORY ----------------
@app.route("/history")
def history():
    if "user" not in session:
        return redirect("/")
    user_mobile = session["user"]
    conn = db_connection()
    cursor = conn.cursor()
    rows = []
    try:
        cursor.execute("""
            SELECT sb.id, sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id, sb.created_at
            FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
            WHERE sb.user_mobile = %s
            ORDER BY sb.slot_date DESC, sb.slot_time DESC
        """, (user_mobile,))
        rows = cursor.fetchall()
    except Exception:
        try:
            cursor.execute("""
                SELECT sb.service_id, s.service_name, sb.slot_date, sb.slot_time, sb.status, sb.token_id
                FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                WHERE sb.user_mobile = %s
            """, (user_mobile,))
            rows = cursor.fetchall()
        except Exception:
            try:
                cursor.execute("""
                    SELECT sb.service_id, s.service_name, sb.status, sb.token_id
                    FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                    WHERE sb.user_mobile = %s
                """, (user_mobile,))
                rows = cursor.fetchall()
            except Exception:
                rows = []
    history_list = []
    for row in rows:
        n = len(row)
        svc_name = row[2] if n >= 3 else (row[1] if n >= 2 else "")
        slot_date = row[3] if n >= 5 else (date.today() if n >= 1 else date.today())
        slot_time = row[4] if n >= 5 else None
        status = row[5] if n >= 6 else (row[2] if n >= 4 else "")
        token_id = row[6] if n >= 7 else (row[3] if n >= 4 else None)
        slot_time_str = slot_time.strftime("%H:%M") if slot_time and hasattr(slot_time, "strftime") else (str(slot_time)[:5] if slot_time else "—")
        token_display = get_token_display_number(cursor, row[1] if n >= 2 else row[0], token_id) if token_id else "—"
        history_list.append({
            "token_display": token_display, "service_name": svc_name, "date": slot_date, "time": slot_time_str, "status": status
        })
    cursor.close()
    return render_template("history.html", history=history_list)

# ---------------- CANCEL BOOKING ----------------
@app.route("/cancel_booking/<int:booking_id>", methods=["POST"])
def cancel_booking(booking_id):
    if "user" not in session:
        return redirect("/")
    user_mobile = session["user"]
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, service_id, slot_id, slot_date, slot_time, status FROM slot_bookings WHERE id=%s AND user_mobile=%s", (booking_id, user_mobile))
    booking = cursor.fetchone()
    if not booking:
        cursor.close()
        flash("Booking not found.", "error")
        return redirect("/my_bookings")
    b_id, svc_id, slot_id, slot_date, slot_time, status = booking
    if status != "BOOKED":
        cursor.close()
        flash("Only booked slots can be cancelled.", "error")
        return redirect("/my_bookings")
    today = date.today()
    if slot_date < today:
        cursor.close()
        flash("Past bookings cannot be cancelled.", "error")
        return redirect("/my_bookings")
    if slot_date == today:
        t = slot_time
        now = datetime.now().time()
        if hasattr(t, "hour") and (t.hour < now.hour or (t.hour == now.hour and t.minute <= now.minute)):
            cursor.close()
            flash("Cannot cancel after slot time has passed.", "error")
            return redirect("/my_bookings")

    cursor.execute("UPDATE slot_bookings SET status='CANCELLED' WHERE id=%s", (booking_id,))
    if slot_id:
        cursor.execute("UPDATE slots SET booked_count = GREATEST(0, booked_count - 1) WHERE id=%s", (slot_id,))
    conn.commit()
    cursor.close()
    flash("Booking cancelled.", "success")
    return redirect("/my_bookings")

# ---------------- CHECK IN ----------------
@app.route("/check_in/<int:booking_id>", methods=["GET", "POST"])
def check_in(booking_id):
    if "user" not in session:
        return redirect("/")
    user_mobile = session["user"]
    today = date.today()
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, service_id, slot_date, slot_time, status, priority_type FROM slot_bookings WHERE id=%s AND user_mobile=%s",
        (booking_id, user_mobile)
    )
    booking = cursor.fetchone()
    if not booking:
        try:
            cursor.execute(
                "SELECT id, service_id, slot_date, slot_time, status FROM slot_bookings WHERE id=%s AND user_mobile=%s",
                (booking_id, user_mobile)
            )
            booking = cursor.fetchone()
            if booking:
                booking = list(booking) + [None]
        except Exception:
            pass
    if not booking:
        cursor.close()
        flash("Booking not found.", "error")
        return redirect("/my_bookings")

    n = len(booking)
    b_id, service_id, slot_date, slot_time, status = booking[0], booking[1], booking[2], booking[3], booking[4]
    priority_type = booking[5] if n > 5 else request.form.get("priority_type") or None

    if status != "BOOKED":
        cursor.close()
        flash("Already checked in or completed.", "error")
        return redirect("/my_bookings")
    if slot_date > today:
        cursor.close()
        flash("Check in on or after your booked date.", "error")
        return redirect("/my_bookings")

    if request.method == "POST":
        priority_type = request.form.get("priority_type") or None
    else:
        priority_type = request.args.get("priority_type") or priority_type
    priority_val = PRIORITY_TYPE_RANK.get((priority_type or "").lower(), 0)

    try:
        cursor.execute(
            "INSERT INTO tokens (service_id, status, priority, priority_type) VALUES (%s, 'WAITING', %s, %s)",
            (service_id, priority_val, priority_type)
        )
    except mysql.connector.errors.ProgrammingError:
        cursor.execute("INSERT INTO tokens (service_id, status, priority) VALUES (%s, 'WAITING', %s)", (service_id, priority_val))
    conn.commit()
    token_id = cursor.lastrowid
    cursor.execute("UPDATE slot_bookings SET token_id=%s, status='CHECKED_IN' WHERE id=%s", (token_id, booking_id))
    if priority_type:
        try:
            cursor.execute("UPDATE slot_bookings SET priority_type=%s WHERE id=%s", (priority_type, booking_id))
        except Exception:
            pass
    conn.commit()
    session["last_token_service"] = service_id
    session["last_token_id"] = token_id

    cursor.execute("SELECT service_name FROM services WHERE id=%s", (service_id,))
    svc_row = cursor.fetchone()
    service_name = svc_row[0] if svc_row else ""
    token_display = get_token_display_number(cursor, service_id, token_id)

    # Generate QR for token
    token_qr_path = None
    try:
        token_qr_path = generate_qr_for_token(token_id, service_id, token_display, service_name)
    except Exception:
        pass

    cursor.close()
    flash(f"Checked in! Your Token #{token_display}.", "success")
    return redirect(f"/live_status/{service_id}/{token_id}?qr=1")

# ---------------- DOCUMENTS & READINESS ----------------
@app.route("/documents/<int:service_id>", methods=["GET", "POST"])
def documents(service_id):
    if "user" not in session:
        return redirect("/")
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT document_name FROM documents WHERE service_id=%s", (service_id,))
    docs = cursor.fetchall()
    cursor.close()
    if request.method == "POST":
        selected = request.form.getlist("docs")
        required_docs = [d[0] for d in docs]
        missing_docs = list(set(required_docs) - set(selected))
        total = len(required_docs)
        readiness = int((len(selected) / total) * 100) if total > 0 else 0
        return render_template("readiness.html", readiness=readiness, service_id=service_id, missing_docs=missing_docs)
    return render_template("documents.html", docs=docs)

# ---------------- TOKEN (walk-in) ----------------
@app.route("/token/<int:service_id>", methods=["GET", "POST"])
def token(service_id):
    if "user" not in session:
        return redirect("/")
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, service_name FROM services WHERE id=%s", (service_id,))
    svc_row = cursor.fetchone()
    if not svc_row:
        cursor.close()
        flash("Service not found.", "error")
        return redirect("/services")
    service_name = svc_row[1]

    priority_type = (request.form.get("priority_type") or request.args.get("priority_type")) if request else None
    priority_val = PRIORITY_TYPE_RANK.get((priority_type or "").lower(), 0)

    if session.get("last_token_service") == service_id and session.get("last_token_id"):
        token_id = session["last_token_id"]
    elif request.method == "GET" and not request.args.get("priority_type"):
        cursor.close()
        return render_template("token_form.html", service_id=service_id, service_name=service_name)
    else:
        conn = db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO tokens (service_id, status, priority, priority_type) VALUES (%s, 'WAITING', %s, %s)",
                (service_id, priority_val, priority_type)
            )
        except mysql.connector.errors.ProgrammingError:
            cursor.execute("INSERT INTO tokens (service_id, status, priority) VALUES (%s, 'WAITING', %s)", (service_id, priority_val))
        except Exception:
            cursor.execute("INSERT INTO tokens (service_id, status) VALUES (%s, 'WAITING')", (service_id,))
        conn.commit()
        token_id = cursor.lastrowid
        cursor.close()
        session["last_token_service"] = service_id
        session["last_token_id"] = token_id

    token_display = get_token_display_number(cursor, service_id, token_id)
    token_qr_path = None
    try:
        token_qr_path = generate_qr_for_token(token_id, service_id, token_display, service_name)
    except Exception:
        pass
    try:
        cursor.execute(
            "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id < %s AND status NOT IN ('COMPLETED', 'MISSED')",
            (service_id, token_id)
        )
        people_ahead = cursor.fetchone()[0]
    except Exception:
        cursor.execute(
            "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id < %s AND status != 'COMPLETED'",
            (service_id, token_id)
        )
        people_ahead = cursor.fetchone()[0]
    try:
        cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (service_id,))
        row = cursor.fetchone()
        avg_time = row[0] if row and row[0] is not None else 5
    except Exception:
        avg_time = 5
    waiting_time = predict_wait_time(avg_time, people_ahead, datetime.now().hour, datetime.now().weekday())
    cursor.close()
    return render_template("token.html", token=token_display, token_id=token_id, people_ahead=people_ahead,
        waiting_time=waiting_time, service_id=service_id, service_name=service_name, token_qr_path=token_qr_path)

# ---------------- LIVE STATUS (queue position + estimated wait) ----------------
@app.route("/live_status/<int:service_id>/<int:token_id>")
def live_status(service_id, token_id):
    if "user" not in session:
        return redirect("/")
    if session.get("last_token_service") != service_id or session.get("last_token_id") != token_id:
        flash("You can only view your own token.", "error")
        return redirect("/services")

    conn = db_connection()
    cursor = conn.cursor()
    token_display = get_token_display_number(cursor, service_id, token_id)
    cursor.execute("SELECT id FROM tokens WHERE service_id=%s AND status='SERVING' ORDER BY id DESC LIMIT 1", (service_id,))
    serving_row = cursor.fetchone()
    now_serving_id = serving_row[0] if serving_row else None
    now_serving_display = get_token_display_number(cursor, service_id, now_serving_id) if now_serving_id else "—"
    cursor.execute(
        "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id < %s AND status NOT IN ('COMPLETED', 'MISSED')",
        (service_id, token_id)
    )
    people_ahead = cursor.fetchone()[0]
    cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (service_id,))
    avg_row = cursor.fetchone()
    avg_time = avg_row[0] if avg_row and avg_row[0] is not None else 5
    waiting_time = predict_wait_time(avg_time, people_ahead, datetime.now().hour, datetime.now().weekday())
    cursor.execute(
        "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND status NOT IN ('COMPLETED', 'MISSED')",
        (service_id,)
    )
    total_in_queue = cursor.fetchone()[0]
    progress = int(((total_in_queue - people_ahead) / total_in_queue) * 100) if total_in_queue > 0 else 100
    progress = max(5, min(progress, 100))
    token_qr_path = None
    try:
        token_qr_path = generate_qr_for_token(token_id, service_id, token_display, "")
    except Exception:
        pass
    cursor.close()

    return render_template("live_status.html",
        token=token_display, people_ahead=people_ahead, waiting_time=waiting_time,
        now_serving=now_serving_display, progress=progress, alert_turn=people_ahead <= 2,
        service_id=service_id, token_id=token_id, token_qr_path=token_qr_path)

# ---------------- QR SCAN (for counter staff - displays token details) ----------------
@app.route("/scan/<int:token_id>")
def scan_token(token_id):
    """Display token details when QR code is scanned at service counter."""
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT t.id, t.service_id, s.service_name, t.status, t.priority, t.priority_type
        FROM tokens t JOIN services s ON t.service_id = s.id
        WHERE t.id=%s
    """, (token_id,))
    row = cursor.fetchone()
    if not row:
        cursor.close()
        return "<html><body><h1>Token not found</h1></body></html>", 404
    n = len(row)
    token_display = get_token_display_number(cursor, row[1], row[0])
    cursor.close()
    return render_template("scan_result.html",
        token_id=row[0], service_id=row[1], service_name=row[2], status=row[3],
        priority=row[4] if n > 4 else 0, priority_type=row[5] if n > 5 else None,
        token_display=token_display)

# ---------------- API: live status (polling) ----------------
@app.route("/api/live_status/<int:service_id>/<int:token_id>")
def api_live_status(service_id, token_id):
    if "user" not in session or session.get("last_token_service") != service_id or session.get("last_token_id") != token_id:
        return jsonify({"error": "Unauthorized"}), 403
    conn = db_connection()
    cursor = conn.cursor()
    token_display = get_token_display_number(cursor, service_id, token_id)
    cursor.execute("SELECT id FROM tokens WHERE service_id=%s AND status='SERVING' ORDER BY id DESC LIMIT 1", (service_id,))
    sr = cursor.fetchone()
    now_serving_display = get_token_display_number(cursor, service_id, sr[0]) if sr else None
    cursor.execute(
        "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND id < %s AND status NOT IN ('COMPLETED', 'MISSED')",
        (service_id, token_id)
    )
    people_ahead = cursor.fetchone()[0]
    cursor.execute("SELECT avg_time FROM service_time WHERE service_id=%s", (service_id,))
    ar = cursor.fetchone()
    avg_time = ar[0] if ar and ar[0] else 5
    waiting_time = predict_wait_time(avg_time, people_ahead, datetime.now().hour, datetime.now().weekday())
    cursor.execute(
        "SELECT COUNT(*) FROM tokens WHERE service_id=%s AND status NOT IN ('COMPLETED', 'MISSED')",
        (service_id,)
    )
    total = cursor.fetchone()[0]
    progress = int(((total - people_ahead) / total) * 100) if total > 0 else 100
    cursor.close()
    return jsonify({
        "token": token_display, "now_serving": now_serving_display, "people_ahead": people_ahead,
        "waiting_time": waiting_time, "progress": progress, "alert_turn": people_ahead <= 2,
    })

# ---------------- ADMIN LOGIN ----------------
@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if not username or not password:
            flash("Username and password required.", "error")
            return render_template("admin_login.html")
        conn = db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, password FROM admin WHERE username=%s", (username,))
        admin = cursor.fetchone()
        if admin:
            stored = admin[2]
            try:
                if check_password_hash(stored, password):
                    session["admin"] = username
                    cursor.close()
                    return redirect("/admin")
            except (ValueError, TypeError):
                pass
            if stored == password:
                hashed = generate_password_hash(password, method="pbkdf2:sha256")
                cursor.execute("UPDATE admin SET password=%s WHERE id=%s", (hashed, admin[0]))
                conn.commit()
                session["admin"] = username
                cursor.close()
                return redirect("/admin")
        cursor.close()
        flash("Invalid username or password.", "error")
    return render_template("admin_login.html")

# ---------------- ADMIN DASHBOARD (live queue, today's bookings, analytics, move priority, search) ----------------
@app.route("/admin", methods=["GET", "POST"])
def admin():
    if "admin" not in session:
        return redirect("/admin_login")

    conn = db_connection()
    cursor = conn.cursor()

    # Today's stats (fallback when tokens has no created_at column)
    today = date.today()
    try:
        cursor.execute("SELECT COUNT(*) FROM tokens WHERE DATE(created_at)=%s AND status NOT IN ('COMPLETED', 'MISSED')", (today,))
        live_queue_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM tokens WHERE DATE(created_at)=%s AND status='COMPLETED'", (today,))
        total_served_today = cursor.fetchone()[0]
        cursor.execute("""
            SELECT HOUR(created_at) AS h, COUNT(*) AS c FROM tokens WHERE DATE(created_at)=%s
            GROUP BY HOUR(created_at) ORDER BY c DESC LIMIT 3
        """, (today,))
        peak_rows = cursor.fetchall()
        peak_hours = [f"{r[0]}:00" for r in peak_rows] if peak_rows else ["N/A"]
        cursor.execute("""
            SELECT HOUR(created_at) AS h, COUNT(*) AS c FROM tokens WHERE DATE(created_at)=%s
            GROUP BY HOUR(created_at)
        """, (today,))
        hourly_rows = cursor.fetchall()
        hourly_chart = {r[0]: r[1] for r in hourly_rows}
        max_hourly = max(hourly_chart.values()) if hourly_chart else 1
    except Exception:
        # tokens table missing created_at or other columns
        try:
            cursor.execute("SELECT COUNT(*) FROM tokens WHERE status NOT IN ('COMPLETED', 'MISSED')")
            live_queue_count = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM tokens WHERE status='COMPLETED'")
            total_served_today = cursor.fetchone()[0]
        except Exception:
            live_queue_count = 0
            total_served_today = 0
        peak_hours = ["N/A"]
        hourly_chart = {}
        max_hourly = 1

    today_bookings = 0
    try:
        cursor.execute("SELECT COUNT(*) FROM slot_bookings WHERE slot_date=%s AND status IN ('BOOKED', 'CHECKED_IN')", (today,))
        today_bookings = cursor.fetchone()[0]
    except Exception:
        try:
            cursor.execute("SELECT COUNT(*) FROM slot_bookings WHERE status IN ('BOOKED', 'CHECKED_IN')")
            today_bookings = cursor.fetchone()[0]
        except Exception:
            today_bookings = 0

    # Average service time (from service_time table; can be refined with token_events)
    try:
        cursor.execute("SELECT AVG(avg_time) FROM service_time")
        avg_svc_row = cursor.fetchone()
        avg_service_time = int(avg_svc_row[0]) if avg_svc_row and avg_svc_row[0] else 5
    except Exception:
        avg_service_time = 5

    # Queue: all tokens ordered by priority DESC, then id
    search_mobile = request.args.get("search_mobile", "").strip()
    filter_service = request.args.get("service_id", type=int)
    filter_status = request.args.get("status", "").strip()

    query = """
        SELECT t.id, t.service_id, s.service_name, t.status, t.priority, t.priority_type, t.created_at
        FROM tokens t JOIN services s ON t.service_id = s.id
        WHERE 1=1
    """
    params = []
    if filter_service:
        query += " AND t.service_id=%s"
        params.append(filter_service)
    if filter_status:
        query += " AND t.status=%s"
        params.append(filter_status)
    query += " ORDER BY t.priority DESC, t.id ASC"
    queue_raw = []
    try:
        cursor.execute(query, tuple(params) if params else ())
        queue_raw = cursor.fetchall()
    except mysql.connector.errors.ProgrammingError:
        try:
            query_fb = query.replace("t.priority_type, ", "")
            cursor.execute(query_fb, tuple(params) if params else ())
            queue_raw = cursor.fetchall()
        except Exception:
            query_fb = "SELECT t.id, t.service_id, s.service_name, t.status, t.priority, t.created_at FROM tokens t JOIN services s ON t.service_id = s.id WHERE 1=1"
            if filter_service:
                query_fb += " AND t.service_id=%s"
            if filter_status:
                query_fb += " AND t.status=%s"
            query_fb += " ORDER BY t.priority DESC, t.id ASC"
            try:
                cursor.execute(query_fb, tuple(params) if params else ())
                queue_raw = cursor.fetchall()
            except Exception:
                query_fb = "SELECT t.id, t.service_id, s.service_name, t.status FROM tokens t JOIN services s ON t.service_id = s.id ORDER BY t.id ASC"
                try:
                    cursor.execute(query_fb)
                    queue_raw = cursor.fetchall()
                except Exception:
                    queue_raw = []

    queue = []
    for row in queue_raw:
        display_num = get_token_display_number(cursor, row[1], row[0])
        priority = row[4] if len(row) > 5 else 0
        priority_type = row[5] if len(row) > 6 else None
        queue.append({"id": row[0], "service_id": row[1], "service_name": row[2], "status": row[3], "priority": priority, "priority_type": priority_type, "display_num": display_num})

    # Next 3 tokens (for highlight and notification)
    next_three = queue[:3] if queue else []

    # Today's bookings list — skip if slot_bookings table/columns don't match
    today_bookings_list = []
    try:
        cursor.execute("""
            SELECT sb.id, sb.user_mobile, s.service_name, sb.slot_date, sb.slot_time, sb.status
            FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
            WHERE sb.slot_date=%s
            ORDER BY sb.slot_time, sb.id
        """, (today,))
        today_bookings_list = cursor.fetchall()
    except Exception:
        try:
            cursor.execute("""
                SELECT sb.id, sb.user_mobile, s.service_name, sb.status
                FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                ORDER BY sb.id
            """)
            today_bookings_list = cursor.fetchall()
        except Exception:
            try:
                cursor.execute("""
                    SELECT sb.user_mobile, s.service_name, sb.status
                    FROM slot_bookings sb JOIN services s ON sb.service_id = s.id
                    ORDER BY sb.user_mobile
                """)
                today_bookings_list = cursor.fetchall()
            except Exception:
                today_bookings_list = []

    next_three_ids = [q["id"] for q in next_three]
    try:
        cursor.execute("SELECT id, service_name FROM services ORDER BY service_name")
        services_list = cursor.fetchall()
    except Exception:
        services_list = []
    cursor.close()

    return render_template("admin.html",
        queue=queue, live_queue_count=live_queue_count, today_bookings=today_bookings,
        total_served_today=total_served_today, avg_service_time=avg_service_time, peak_hours=peak_hours,
        today_bookings_list=today_bookings_list, next_three=next_three, next_three_ids=next_three_ids,
        services_list=services_list, search_mobile=search_mobile,
        filter_service=filter_service, filter_status=filter_status,
        hourly_chart=hourly_chart, max_hourly=max_hourly)

# ---------------- UPDATE TOKEN STATUS (POST, commit, UI refresh) ----------------
@app.route("/update/<int:token_id>/<status>", methods=["GET", "POST"])
def update(token_id, status):
    if "admin" not in session:
        return redirect("/admin_login")
    if status not in ("WAITING", "SERVING", "COMPLETED", "MISSED"):
        flash("Invalid status.", "error")
        return redirect("/admin")

    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT status FROM tokens WHERE id=%s", (token_id,))
    row = cursor.fetchone()
    if not row:
        cursor.close()
        flash("Token not found.", "error")
        return redirect("/admin")
    old_status = row[0]

    try:
        if status == "SERVING":
            cursor.execute("UPDATE tokens SET served_at=NOW() WHERE id=%s", (token_id,))
        elif status == "COMPLETED":
            cursor.execute("UPDATE tokens SET completed_at=NOW() WHERE id=%s", (token_id,))
    except mysql.connector.errors.ProgrammingError:
        pass  # served_at/completed_at columns may not exist
    cursor.execute("UPDATE tokens SET status=%s WHERE id=%s", (status, token_id))
    if status == "COMPLETED":
        cursor.execute("UPDATE slot_bookings SET status='COMPLETED' WHERE token_id=%s", (token_id,))
    conn.commit()
    cursor.close()
    flash("Status updated.", "success")
    return redirect("/admin")

# ---------------- ADMIN: Move token priority ----------------
@app.route("/admin/token/<int:token_id>/priority", methods=["POST"])
def admin_token_priority(token_id):
    if "admin" not in session:
        return redirect("/admin_login")
    new_priority = request.form.get("priority", type=int)
    if new_priority is None:
        new_priority = 0
    priority_type = request.form.get("priority_type") or None
    if priority_type and priority_type not in ("senior", "pregnant", "disabled", "emergency"):
        priority_type = None
    conn = db_connection()
    cursor = conn.cursor()
    try:
        if priority_type:
            pval = PRIORITY_TYPE_RANK.get(priority_type.lower(), new_priority)
            cursor.execute("UPDATE tokens SET priority=%s, priority_type=%s WHERE id=%s", (max(pval, new_priority), priority_type, token_id))
        else:
            cursor.execute("UPDATE tokens SET priority=%s WHERE id=%s", (new_priority, token_id))
    except mysql.connector.errors.ProgrammingError:
        cursor.execute("UPDATE tokens SET priority=%s WHERE id=%s", (new_priority, token_id))
    conn.commit()
    cursor.close()
    flash("Priority updated.", "success")
    return redirect("/admin")

# ---------------- ADMIN: Mark token as Missed ----------------
@app.route("/admin/token/<int:token_id>/missed", methods=["POST"])
def admin_token_missed(token_id):
    if "admin" not in session:
        return redirect("/admin_login")
    conn = db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE tokens SET status='MISSED' WHERE id=%s", (token_id,))
    cursor.execute("UPDATE slot_bookings SET status='MISSED' WHERE token_id=%s", (token_id,))
    conn.commit()
    cursor.close()
    flash("Token marked as Missed.", "success")
    return redirect("/admin")

# ---------------- ADMIN: User list ----------------
@app.route("/admin/users")
def admin_users():
    if "admin" not in session:
        return redirect("/admin_login")
    conn = db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, mobile, name, created_at FROM users ORDER BY created_at DESC LIMIT 100")
        users_list = cursor.fetchall()
    except Exception:
        try:
            cursor.execute("SELECT id, mobile FROM users ORDER BY id DESC LIMIT 100")
            users_list = cursor.fetchall()
        except Exception:
            users_list = []
    cursor.close()
    return render_template("admin_users.html", users=users_list)

# ---------------- ADMIN: Services CRUD (multi-service) ----------------
@app.route("/admin/services", methods=["GET", "POST"])
def admin_services():
    if "admin" not in session:
        return redirect("/admin_login")
    conn = db_connection()
    cursor = conn.cursor()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            name = request.form.get("service_name", "").strip()
            if name:
                cursor.execute("INSERT INTO services (service_name) VALUES (%s)", (name,))
                conn.commit()
                flash("Service added.", "success")
        elif action == "delete":
            sid = request.form.get("service_id", type=int)
            if sid:
                cursor.execute("DELETE FROM services WHERE id=%s", (sid,))
                conn.commit()
                flash("Service removed.", "success")
        return redirect("/admin/services")
    try:
        cursor.execute("SELECT id, service_name, description FROM services ORDER BY service_name")
    except Exception:
        cursor.execute("SELECT id, service_name FROM services ORDER BY service_name")
    rows = cursor.fetchall()
    services_list = [(r[0], r[1], r[2] if len(r) > 2 else None) for r in rows]
    cursor.close()
    return render_template("admin_services.html", services=services_list)

# ---------------- ADMIN: Analytics API (for dashboards) ----------------
@app.route("/admin/api/analytics")
def admin_api_analytics():
    if "admin" not in session:
        return jsonify({"error": "Unauthorized"}), 403
    conn = db_connection()
    cursor = conn.cursor()
    today = date.today()
    try:
        cursor.execute("""
            SELECT s.id, s.service_name, COUNT(t.id) as queue_count,
                   (SELECT AVG(avg_time) FROM service_time WHERE service_id=s.id) as avg_time
            FROM services s
            LEFT JOIN tokens t ON t.service_id=s.id AND t.status NOT IN ('COMPLETED','MISSED')
            GROUP BY s.id, s.service_name
        """)
        services_stats = [{"id": r[0], "name": r[1], "queue": r[2], "avg_min": int(r[3] or 5)} for r in cursor.fetchall()]
        cursor.execute("SELECT HOUR(created_at), COUNT(*) FROM tokens WHERE DATE(created_at)=%s GROUP BY HOUR(created_at)", (today,))
        hourly = {r[0]: r[1] for r in cursor.fetchall()}
    except Exception:
        services_stats = []
        hourly = {}
    cursor.close()
    return jsonify({"services": services_stats, "hourly_today": hourly})

# ---------------- ADMIN: Daily report CSV ----------------
@app.route("/admin/report/csv")
def admin_report_csv():
    if "admin" not in session:
        return redirect("/admin_login")
    today = date.today()
    conn = db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT t.id, s.service_name, t.status, t.priority, t.created_at, t.served_at, t.completed_at
            FROM tokens t JOIN services s ON t.service_id = s.id
            WHERE DATE(t.created_at)=%s
            ORDER BY t.service_id, t.id
        """, (today,))
        rows = cursor.fetchall()
        output = io.StringIO()
        w = csv.writer(output)
        w.writerow(["Token ID", "Service", "Status", "Priority", "Created", "Served", "Completed"])
        for row in rows:
            w.writerow([row[0], row[1], row[2], row[3],
                        row[4].strftime("%Y-%m-%d %H:%M") if row[4] else "",
                        row[5].strftime("%Y-%m-%d %H:%M") if row[5] else "",
                        row[6].strftime("%Y-%m-%d %H:%M") if row[6] else ""])
    except mysql.connector.errors.ProgrammingError:
        # tokens has no created_at / priority / served_at / completed_at
        cursor.execute("""
            SELECT t.id, s.service_name, t.status
            FROM tokens t JOIN services s ON t.service_id = s.id
            ORDER BY t.service_id, t.id
        """)
        rows = cursor.fetchall()
        output = io.StringIO()
        w = csv.writer(output)
        w.writerow(["Token ID", "Service", "Status"])
        for row in rows:
            w.writerow([row[0], row[1], row[2]])
    cursor.close()
    output.seek(0)
    return send_file(
        io.BytesIO(output.getvalue().encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"queue_report_{today}.csv"
    )

# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# ---------------- ERROR HANDLER (shows cause of 500) ----------------
@app.errorhandler(500)
def handle_500(e):
    """Show the actual error so you can fix it (e.g. run migration_schema.sql)."""
    import traceback
    tb = traceback.format_exc() if hasattr(e, "__traceback__") and e.__traceback__ else str(e)
    err_msg = str(e)
    return f"""
    <html><body style="font-family:sans-serif;padding:20px;background:#1e293b;color:#f8fafc;">
    <h1>HTTP 500 – Server Error</h1>
    <p><b>Error:</b> {err_msg}</p>
    <pre style="background:#334155;padding:16px;overflow:auto;font-size:12px;">{tb}</pre>
    <p>Common fix: If you see "Unknown column" or "field list", run the database migration:</p>
    <pre>mysql -u root -p smart_queue &lt; migration_schema.sql</pre>
    <p>Or create the database from scratch: <code>mysql -u root -p smart_queue &lt; database.sql</code></p>
    </body></html>
    """, 500

# ---------------- RUN ----------------
if __name__ == "__main__":
    debug = os.getenv("FLASK_DEBUG", "true").lower() in ("true", "1", "yes")
    app.run(debug=debug)
