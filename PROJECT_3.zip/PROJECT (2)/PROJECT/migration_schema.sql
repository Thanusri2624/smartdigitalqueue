-- Run this if you already have smart_queue DB and need to add new columns/tables only.
-- mysql -u root -p smart_queue < migration_schema.sql

USE smart_queue;

-- Tokens: add priority and timestamps, extend status
ALTER TABLE tokens ADD COLUMN priority INT NOT NULL DEFAULT 0 AFTER status;
ALTER TABLE tokens ADD COLUMN served_at TIMESTAMP NULL AFTER priority;
ALTER TABLE tokens ADD COLUMN completed_at TIMESTAMP NULL AFTER served_at;
ALTER TABLE tokens MODIFY COLUMN status VARCHAR(20);
UPDATE tokens SET status = 'COMPLETED' WHERE status = 'COMPLETED';
ALTER TABLE tokens MODIFY COLUMN status ENUM('WAITING', 'SERVING', 'COMPLETED', 'MISSED') DEFAULT 'WAITING';

-- Slot_bookings: add qr_path, slot_id; extend status
ALTER TABLE slot_bookings ADD COLUMN qr_path VARCHAR(255) NULL;
ALTER TABLE slot_bookings ADD COLUMN slot_id INT NULL;
ALTER TABLE slot_bookings MODIFY COLUMN status VARCHAR(20);
UPDATE slot_bookings SET status = status WHERE 1=1;
ALTER TABLE slot_bookings MODIFY COLUMN status ENUM('BOOKED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED', 'MISSED') DEFAULT 'BOOKED';

-- Create token_events if not exists
CREATE TABLE IF NOT EXISTS token_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    token_id INT NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE CASCADE
);
