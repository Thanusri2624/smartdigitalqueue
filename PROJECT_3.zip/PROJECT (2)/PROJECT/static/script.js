const alertFlag = document.getElementById("alertFlag");

if (alertFlag) {
    if (!localStorage.getItem("turnAlertShown")) {
        alert("⚠️ Your turn is coming soon. Please be ready!");
        localStorage.setItem("turnAlertShown", "yes");
    }
}
