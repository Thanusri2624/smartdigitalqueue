# Smart Queue Management System

A production-ready queue management system for banks, government offices, and service centers.

## Features

- **User Authentication** - Registration & login with mobile + password (pbkdf2:sha256 hashing)
- **Slot Booking** - Book service slots with date/time and optional priority
- **Priority Queue** - Senior citizens, pregnant women, disabled, emergency get higher priority
- **QR Codes** - Unique QR per booking and token for quick counter verification
- **Live Queue Tracking** - Real-time position, people ahead, AI-estimated wait time
- **Notifications** - Browser notifications when your turn is approaching
- **Voice Assistance** - Read-aloud for accessibility (elderly users)
- **Admin Dashboard** - Queue control, user management, analytics, CSV reports
- **AI Wait Prediction** - Factors in rush hours, weekends, queue length

## Setup

1. **Database** (MySQL):
   ```bash
   mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS smart_queue"
   mysql -u root -p smart_queue < database.sql
   mysql -u root -p smart_queue < migration_schema.sql
   mysql -u root -p smart_queue < migration_slots.sql
   mysql -u root -p smart_queue < migration_priority.sql  # optional: priority & QR
   ```

2. **Environment** (.env):
   ```
   SECRET_KEY=your-secret-key
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=yourpassword
   DB_NAME=smart_queue
   FLASK_DEBUG=true
   ```

3. **Run**:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
   Open http://127.0.0.1:5000

## Default Admin

- Username: `admin`
- Password: `admin123` (change in production)

## QR Code Scan

Token QR codes encode `/scan/<token_id>` - when scanned, displays token details for counter staff.
