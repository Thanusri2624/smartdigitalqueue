# Smart Queue Management System – Upgrade Summary

## 1. What Changed

### Core fixes
- **Slot booking**: Inserts correctly into `slots` and `slot_bookings` with proper `slot_date`/`slot_time` types and `slot_id`; commits after each write.
- **Status updates**: Token status (Waiting, Serving, Completed, Missed) updates in DB with `conn.commit()` and redirect so the UI shows the new state.
- **QR code**: After booking, a QR is generated with `qrcode` and saved under `static/qr/booking_<id>.png`; path stored in `slot_bookings.qr_path`.
- **Forms**: All forms use `method="post"` and include `csrf_token`; routes use POST where needed (e.g. cancel, status, priority).
- **Database**: Per-request connections via `get_db()` and `db_connection()`, with `conn.commit()` after writes and `cursor.close()`; teardown closes the connection.

### User features
- **Login/sessions**: Citizen login with session; after login redirect to **Dashboard** (`/dashboard`).
- **Dashboard**: `/dashboard` shows total bookings, next booking, live queue position and estimated wait, links to My Bookings and History.
- **View Previous History**: `/history` shows token number, service, date, time, status for all past bookings.
- **Cancel booking**: Cancel allowed only when status is BOOKED and slot is in the future; POST to `/cancel_booking/<id>`.
- **Live queue position & ETA**: Shown on `/live_status/<service_id>/<token_id>` and in the dashboard for the active token.

### AI features
- **Waiting time prediction**: Uses people ahead and average service time; shown on booking confirmation, dashboard, and live status.
- **Smart slot recommendation**: Slot booking page shows labels **Low Crowd / Medium / High** per slot from `booked_count`/capacity.
- **Queue analytics**: Admin dashboard shows average service time, peak hours, total served today, and an hourly activity chart.

### Admin features
- **Admin dashboard**: Live queue count, today’s bookings, analytics cards, hourly chart, today’s bookings list.
- **Move token priority**: Form on each row to set `priority`; POST to `/admin/token/<id>/priority`.
- **Search/filter**: Filter queue by service and status (GET form on admin page).
- **Notifications**: Next 3 tokens in the queue are highlighted (CSS class `token-next`).

### Real-world features
- **Token expiry**: Admin can mark a token as **Missed** (button + POST to `/admin/token/<id>/missed`); `slot_bookings` updated to MISSED when applicable.
- **Multi-service**: Admin can add/delete services at `/admin/services` (Banking, Certificates, Hospital, etc.).
- **Daily report**: `/admin/report/csv` exports today’s queue (tokens) as CSV.
- **Passwords**: Stored with `werkzeug.security.generate_password_hash` / `check_password_hash`.
- **Config**: DB and app config from environment variables (`.env`: `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, `SECRET_KEY`, `FLASK_DEBUG`).

---

## 2. Where Each Code Section Lives

| Feature | Location |
|--------|----------|
| DB connection, helpers, prediction | `app.py`: top (get_db, db_connection, get_token_display_number, parse_time, predict_wait_time, slot_crowd_label, generate_qr_for_booking) |
| User login / register / dashboard | `app.py`: `/`, `/register`, `/dashboard` |
| Slot booking (fix + QR) | `app.py`: `/slot_booking/<service_id>`, `/booking_confirmation/<id>` |
| My bookings, history, cancel | `app.py`: `/my_bookings`, `/history`, `/cancel_booking/<id>` (POST) |
| Check-in, token, live status, API | `app.py`: `/check_in/<id>`, `/token/<service_id>`, `/live_status/...`, `/api/live_status/...` |
| Admin login & dashboard | `app.py`: `/admin_login`, `/admin` |
| Status update, priority, missed | `app.py`: `/update/<token_id>/<status>`, `/admin/token/<id>/priority`, `/admin/token/<id>/missed` |
| Admin services CRUD | `app.py`: `/admin/services` |
| Daily CSV report | `app.py`: `/admin/report/csv` |
| Full schema | `database.sql` |
| Migration (add columns/tables) | `migration_schema.sql` |
| User templates | `templates/`: login, register, dashboard, services, slot_booking, my_bookings, history, booking_confirmation, documents, readiness, token, live_status |
| Admin templates | `templates/`: admin_login, admin, admin_services |
| Styles | `static/style.css` |

---

## 3. How to Run the Project

### Prerequisites
- Python 3.8+
- MySQL server
- `.env` in project root (see below)

### 1. Environment
Create or edit `.env`:

```env
SECRET_KEY=your-secret-key
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=smart_queue
FLASK_DEBUG=true
```

### 2. Database
- Create DB: `CREATE DATABASE IF NOT EXISTS smart_queue;`
- **Fresh install**:  
  `mysql -u root -p smart_queue < database.sql`
- **Existing DB (add new columns/tables)**:  
  `mysql -u root -p smart_queue < migration_schema.sql`  
  (If you get “duplicate column” errors, skip those lines or run the file once.)

### 3. Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run Flask
```bash
python app.py
```
Or: `flask run` (after `set FLASK_APP=app.py` on Windows).

### 5. Use the app
- **User**: Open `http://127.0.0.1:5000/` → Login or Register → Dashboard → Services → Book slot / View history / Cancel if allowed.
- **Admin**: `http://127.0.0.1:5000/admin_login` → Dashboard → Manage Services, filter queue, set priority, Mark Missed, Download CSV.

### 6. First-time admin user
If you don’t have an admin row:

```sql
INSERT INTO admin (username, password) VALUES ('admin', '<hashed_password>');
```

To generate a hash:

```bash
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('your_password'))"
```
Use the printed value in the `INSERT` above.

---

## SQL for New Tables/Columns (reference)

- **tokens**: `priority INT DEFAULT 0`, `served_at`, `completed_at`, `status` including `MISSED`.
- **slot_bookings**: `slot_id`, `qr_path`, `status` including `CANCELLED`, `MISSED`.
- **token_events**: optional table for analytics.

Full definitions are in `database.sql` and `migration_schema.sql`.
