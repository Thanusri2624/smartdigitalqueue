#!/usr/bin/env python3
"""
Migration script to enlarge `password` columns for `users` and `admin` tables.
Usage:
  - Put DB credentials in a `.env` file or set environment variables: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME
  - Run: python migrate_db.py
"""

import os
from dotenv import load_dotenv
import mysql.connector

load_dotenv()

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DB_NAME = os.getenv("DB_NAME", "smart_queue")

if not DB_USER or DB_PASSWORD is None:
    print("DB_USER or DB_PASSWORD not found in environment; prompting for credentials.")
    DB_USER = input("DB_USER: ")
    DB_PASSWORD = input("DB_PASSWORD: ")

print(f"Connecting to {DB_HOST}/{DB_NAME} as {DB_USER}")

try:
    cnx = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        autocommit=False
    )
    cursor = cnx.cursor()

    stmts = [
        "ALTER TABLE admin MODIFY password VARCHAR(1024);",
        "ALTER TABLE users MODIFY password VARCHAR(1024);"
    ]

    for s in stmts:
        print("Executing:", s)
        cursor.execute(s)

    cnx.commit()
    print("Migration applied successfully.")

except mysql.connector.Error as err:
    print("MySQL error:", err)
    try:
        cnx.rollback()
    except Exception:
        pass
    raise

finally:
    try:
        cursor.close()
    except Exception:
        pass
    try:
        cnx.close()
    except Exception:
        pass
