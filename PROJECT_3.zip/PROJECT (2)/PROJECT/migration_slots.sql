-- Run this if you have an existing database and need slot booking
-- Usage: mysql -u root -p smart_queue < migration_slots.sql

USE smart_queue;

-- Add slot_id to tokens (if missing)
-- ALTER TABLE tokens ADD COLUMN slot_id INT NULL;

-- Slots table
CREATE TABLE IF NOT EXISTS slots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_id INT NOT NULL,
    slot_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    capacity INT NOT NULL DEFAULT 5,
    booked_count INT NOT NULL DEFAULT 0,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    UNIQUE KEY (service_id, slot_date, slot_time)
);

-- Customer slot bookings (history)
CREATE TABLE IF NOT EXISTS slot_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_mobile VARCHAR(20) NOT NULL,
    service_id INT NOT NULL,
    slot_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    status ENUM('BOOKED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED') DEFAULT 'BOOKED',
    token_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    FOREIGN KEY (token_id) REFERENCES tokens(id) ON DELETE SET NULL
);
